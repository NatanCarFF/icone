// js/main.js

// Este arquivo será usado para scripts globais ou utilitários mais tarde.
// Por enquanto, ele está vazio.
console.log("Gerador de Ícones Android carregado!");